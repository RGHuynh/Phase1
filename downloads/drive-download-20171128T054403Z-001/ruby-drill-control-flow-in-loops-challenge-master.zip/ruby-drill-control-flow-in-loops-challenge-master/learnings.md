# Working with Break, Next, and Return

## In Loops
### What is the difference between return and break?


### What does next do?


### How would we stop a loop from continuing without exiting the method?


## In Blocks
### What happens when we return within a block?


### What does a block return if we call break?


### What does a block return if we call next?


### Does ordering affect next, break, and return? If so, how?
