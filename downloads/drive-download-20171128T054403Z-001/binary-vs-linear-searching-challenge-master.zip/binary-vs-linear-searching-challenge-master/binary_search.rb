def binary_search(target, elements)
end
