def linear_search(target, elements)
end
