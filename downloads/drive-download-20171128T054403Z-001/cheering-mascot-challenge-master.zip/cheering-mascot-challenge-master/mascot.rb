# Get input from the user:  the cheer
def call_out_cheer
end

# Determine the mascot's response based on the argument
# passed to the method
def mascot_sign_for(input)
end

# Print the argument passed to the method
def display(response)
end

# This method will control the flow of the application,
# making use of the other three methods.
def coordinate_cheers
end
