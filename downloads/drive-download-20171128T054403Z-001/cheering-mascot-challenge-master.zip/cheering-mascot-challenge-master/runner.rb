require_relative "mascot"

# This line calls the coordinate_cheers method,
# starting the cheers.
coordinate_cheers
