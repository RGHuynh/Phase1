require_relative 'boggle_board'

describe "Boggle Board - Release 1" do

  let(:board) { BoggleBoard.new }

  pending "Write your own tests here"
end

describe "Boggle Board - Release 2" do
  pending "Write your own tests here"
end
