# You should re-use and modify your old BoggleBoard class
# to support the new requirements

class BoggleBoard
  def initialize
  end

  def shake!
  end

  def to_s
  end
end
