require_relative '../number_in_words'

describe 'number_in_words' do
end
