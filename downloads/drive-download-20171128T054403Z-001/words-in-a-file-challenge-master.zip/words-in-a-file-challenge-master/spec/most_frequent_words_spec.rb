require_relative '../most_frequent_words'

describe 'most_frequent_words' do
  let(:test_text_file) { File.expand_path('../support/test.txt', __FILE__) }

end
