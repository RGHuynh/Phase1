require_relative '../convert_table'

describe 'converting a roster from a nested array to a collection of hashes' do
end
