require_relative '../tic_tac_toe'

describe 'generating a tic-tac-toe board' do
end
