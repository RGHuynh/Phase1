def iterative_nth_fibonacci_number(n)
end

def recursive_nth_fibonacci_number(n)
end
