require_relative '../binary_search'

describe 'binary_search' do
end
