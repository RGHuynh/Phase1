class LinkedList

end

