require_relative '../linked_list'

describe LinkedList do

end
