# Review Reflect On Learning 
 
##Learning Competencies 

##Summary 

 List 10 major topics covered this week (e.g. *recursion*).

Then choose two of these topics and describe what you learned about them in several sentences.

Give at least one code example (that was not provided in the challenges) to illustrate your description. 

##Releases
###Release 0 

##Optimize Your Learning 

##Resources