## List 10 topics




## Choose two and write a description




## Write code to illustrate one of your descriptions

```ruby
# Your code here

```