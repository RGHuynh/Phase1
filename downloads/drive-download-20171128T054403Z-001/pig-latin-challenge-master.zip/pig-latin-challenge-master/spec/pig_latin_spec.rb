require_relative('../pig_latin')

describe 'Converting single words to Pig Latin' do
end

describe 'Converting a sentence to Pig Latin' do
end
