require_relative '../anagrams'

describe 'anagrams?' do
end
