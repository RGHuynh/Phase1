require_relative 'factorial'
require_relative 'fibonacci'
