require_relative 'factorial'

number = 5000
factorial = factorial_recursive(number)

puts factorial
