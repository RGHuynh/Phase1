def factorial_iterative(n)
end

def factorial_recursive(n)
end
