# Set Restrictions

We may not use Ruby's `Set` library.