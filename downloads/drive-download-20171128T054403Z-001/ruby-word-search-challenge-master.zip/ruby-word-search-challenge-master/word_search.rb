def straight_line_include?(word, puzzle)
end

def snaking_include?(word, puzzle)
end
