require_relative '../sudoku'

describe "Sudoku" do
end
