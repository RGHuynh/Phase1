def shuffle(array)
end
