class Dog
  attr_reader :name, :license

  def initialize(name, license)
    @name = name
    @license = license
  end
end
