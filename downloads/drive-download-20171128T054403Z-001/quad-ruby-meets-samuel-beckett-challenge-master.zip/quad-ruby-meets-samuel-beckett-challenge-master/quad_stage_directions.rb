def quad_stage_directions(actors)
end

