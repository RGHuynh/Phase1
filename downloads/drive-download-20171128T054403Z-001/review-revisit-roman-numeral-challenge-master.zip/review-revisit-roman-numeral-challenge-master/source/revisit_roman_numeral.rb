# 1: Grab a solution to Roman Numerals
# 
# Source: SOURCE_URL
# Author: AUTHOR_NAME

# ------------
# 2. Explain the code in plain English


# ------------
# 3. Translate to pseudocode


# ------------
# 4. Test the code


# ------------
# 5. Refactor
#
# Write the refactored method below. 
# Comment out the original so that your tests are run 
# against the refactored version.