require_relative '../prime_factors'

describe 'prime_factors' do
end
