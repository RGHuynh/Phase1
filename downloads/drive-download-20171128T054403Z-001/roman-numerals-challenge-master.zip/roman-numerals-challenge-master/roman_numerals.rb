def convert_to_roman(arabic_number)
  # Your code goes here
end
