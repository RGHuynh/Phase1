def destroy_message(message)
end

def destroy_message!(message)
end
