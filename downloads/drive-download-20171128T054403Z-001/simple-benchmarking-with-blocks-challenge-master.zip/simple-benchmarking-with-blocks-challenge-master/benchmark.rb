# Accepts a block and returns how many seconds
# it takes to execute the code in the block.
def benchmark
end
