=begin
Release 0:  List the smells that can be combated by extracting a method.


Release 1:  Find code that has one or more of the listed smells. Copy the old code below and name the smell.


=end




# Release 2:  Apply the extract method refactoring to clean up the smells.
