require_relative '../my_queue'

describe MyQueue do
end
