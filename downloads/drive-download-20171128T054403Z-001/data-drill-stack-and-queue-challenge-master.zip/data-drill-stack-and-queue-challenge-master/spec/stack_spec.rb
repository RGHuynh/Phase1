require_relative '../my_stack'

describe MyStack do
end
