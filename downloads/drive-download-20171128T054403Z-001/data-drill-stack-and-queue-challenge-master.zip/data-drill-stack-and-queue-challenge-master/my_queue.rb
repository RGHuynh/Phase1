class MyQueue
end
