require_relative 'bottle_song_lyrics'

song_lyrics = bottle_song_lyrics(99)
puts song_lyrics
