require_relative '../bottle_song_lyrics'

describe 'bottle_song_lyrics' do
  # Your tests here ...
end
